
#define WIN32_LEAN_AND_MEAN

#include <windows.h>

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

#define NUMSTEPS 109

#define LLSTEP  ((LLONG_MAX - INT_MAX)/NUMSTEPS)
#define LSTEP   (INT_MAX/NUMSTEPS)
#define ULLSTEP ((ULLONG_MAX - UINT_MAX)/NUMSTEPS)
#define ULSTEP  (UINT_MAX/NUMSTEPS)

/* wcrt 64-bit arithmetic functions */
extern __int64 nwalldiv(__int64 x, __int64 y);
extern __int64 nwalldvrm(__int64 x, __int64 y, __int64 *r);
extern __int64 nwallmul(__int64 x, __int64 y);
extern __int64 nwallrem(__int64 x, __int64 y);
extern __int64 nwallshl(__int64 x, int n);
extern __int64 nwallshr(__int64 x, int n);
extern unsigned __int64 nwaulldiv(unsigned __int64 x, unsigned __int64 y);
extern unsigned __int64 nwaulldvrm(unsigned __int64 x, unsigned __int64 y, unsigned __int64 *r);
extern unsigned __int64 nwaullrem(unsigned __int64 x, unsigned __int64 y);
extern unsigned __int64 nwaullshr(unsigned __int64 x, int n);

/* microsoft 64-bit arithmetic functions */
extern __int64 msalldiv(__int64 x, __int64 y);
extern __int64 msalldvrm(__int64 x, __int64 y, __int64 *r);
extern __int64 msallmul(__int64 x, __int64 y);
extern __int64 msallrem(__int64 x, __int64 y);
extern __int64 msallshl(__int64 x, int n);
extern __int64 msallshr(__int64 x, int n);
extern unsigned __int64 msaulldiv(unsigned __int64 x, unsigned __int64 y);
extern unsigned __int64 msaulldvrm(unsigned __int64 x, unsigned __int64 y, unsigned __int64 *r);
extern unsigned __int64 msaullrem(unsigned __int64 x, unsigned __int64 y);
extern unsigned __int64 msaullshr(unsigned __int64 x, int n);

typedef __int64 (*PFUNC1)(__int64, int);
typedef __int64 (*PFUNC2)(__int64, __int64);
typedef __int64 (*PFUNC3)(__int64, __int64, __int64 *);
typedef void (*PTIMEFUNC)(void *);

/* if more than one cpu, try to limit us to the second */
void fix_affinity()
{
    DWORD pam, sam;
    HANDLE hProcess;

    hProcess = GetCurrentProcess();

    GetProcessAffinityMask(hProcess, &pam, &sam);

    if (pam & 0x02) SetProcessAffinityMask(hProcess, 0x02);
}

/* x values that test some problem areas */
__int64 xtable[] = {
    0x0000000000000000ll,
    0x0000000000000001ll,
    0x000000000000000fll,
    0x000000007fffffffll,
    0x00000000ffffffffll,
    0x0000000100000000ll,
    0x0000000100000001ll,
    0x000000010000000fll,
    0x0000000f0000000fll,
    0x0000ffff000000ffll,
    0x7fffffff00000000ll,
    0x7fffffff00000001ll,
    0x7fffffff0000000fll,
    0x7ffffffffffffffell,
    0x7fffffffffffffffll,
    -1,
    LLONG_MIN + 1,
    LLONG_MIN,
    0x8000000000000000ull,
    0x8000000000000001ull,
    0xf00000000000000full,
    0x8000000100000000ull,
    0x8000000100000001ull,
    0x800000010000000full,
    0xffffffff00000000ull,
    0xffffffff00000001ull,
    0xffffffff0000000full,
    0xfffffffffffffffeull,
    0xfffffffeffffffffull,
    0xffffffffffffffffull,
};

const int XSIZE = sizeof(xtable)/sizeof(xtable[0]);

/* y values that test some problem areas */
__int64 ytable[] = {
    0x0000000000000001ll,
    0x000000000000000fll,
    0x000000007fffffffll,
    0x00000000ffffffffll,
    0x0000000100000000ll,
    0x0000000100000001ll,
    0x000000010000000fll,
    0x0000000f0000000fll,
    0x0000ffff000000ffll,
    0x7fffffff00000000ll,
    0x7fffffff00000001ll,
    0x7fffffff0000000fll,
    0x7ffffffffffffffell,
    0x7fffffffffffffffll,
    -1,
    LLONG_MIN + 1,
    LLONG_MIN,
    0x8000000000000000ull,
    0x8000000000000001ull,
    0xf00000000000000full,
    0x8000000100000000ull,
    0x8000000100000001ull,
    0x800000010000000full,
    0xffffffff00000000ull,
    0xffffffff00000001ull,
    0xffffffff0000000full,
    0xfffffffffffffffeull,
    0xfffffffeffffffffull,
    0xffffffffffffffffull,
};

const int YSIZE = sizeof(ytable)/sizeof(ytable[0]);

/* helper functions for comparing the results of two functions */

int func1_compare(PFUNC1 func1, PFUNC1 func2)
{
    int i, j;

    for (i = 0; i < XSIZE; ++i)
    {
        for (j = 0; j < 130; ++j)
        {
            if (func1(xtable[i], j) != func2(xtable[i], j)) return 1;
        }
    }

    return 0;
}

int func2_compare(PFUNC2 func1, PFUNC2 func2)
{
    int i, j;

    for (i = 0; i < XSIZE; ++i)
    {
        for (j = 0; j < YSIZE; ++j)
        {
            if (func1(xtable[i], ytable[j]) != func2(xtable[i], ytable[j])) return 1;
        }
    }

    return 0;
}

int func3_compare(PFUNC3 func1, PFUNC3 func2)
{
    int i, j;
    __int64 r1, r2;

    for (i = 0; i < XSIZE; ++i)
    {
        for (j = 0; j < YSIZE; ++j)
        {
            r1 = 1; r2 = 2;
            if (func1(xtable[i], ytable[j], &r1) != func2(xtable[i], ytable[j], &r2)) return 1;
            if (r1 != r2) return 1;
        }
    }

    return 0;
}

/* helper functions for calling shift type functions */

void func1_32(void *param)
{
    PFUNC1 func;
    int i, n;

    func = (PFUNC1) param;

    /* perform shifts of 0-31 bits */
    for (i = 0; i < 512; ++i)
        for (n = 0; n < 32; ++n)
            { func(0x1234567812345678ll, n); func(0x1234567812345678ll, n); }
}

void func1_64(void *param)
{
    PFUNC1 func;
    int i, n;

    func = (PFUNC1) param;

    /* perform shifts of 32-63 bits */
    for (i = 0; i < 512; ++i)
        for (n = 32; n < 64; ++n)
            { func(0x1234567812345678ll, n); func(0x1234567812345678ll, n); }
}

void func1_96(void *param)
{
    PFUNC1 func;
    int i, n;

    func = (PFUNC1) param;

    /* perform shifts of 64-95 bits */
    for (i = 0; i < 512; ++i)
        for (n = 64; n < 96; ++n)
            { func(0x1234567812345678ll, n); func(0x1234567812345678ll, n); }
}

/* helper functions for calling mul/div type functions */

void func2_hi_hi(void *param)
{
    PFUNC2 func;
    __int64 x, y;

    func = (PFUNC2) param;

    /* positive values above 32 bit, positive values above 32bit */
    for (x = LLONG_MAX; x > INT_MAX; x -= LLSTEP)
        for (y = x; y > INT_MAX; y -= LLSTEP)
            func(x, y);

    /* negative values above 32 bit, negative values above 32 bit */
    for (x = LLONG_MIN; x < INT_MIN; x += LLSTEP)
        for (y = x; y < INT_MIN; y += LLSTEP)
            func(x, y);
}

void func2_hi_lo(void *param)
{
    PFUNC2 func;
    __int64 x, y;

    func = (PFUNC2) param;

    /* positive values above 32 bit, positive values below 32 bit */
    for (x = LLONG_MAX; x > INT_MAX; x -= LLSTEP)
        for (y = INT_MAX; y > 0; y -= LSTEP)
            func(x, y);

    /* negative values above 32 bit, negative values below 32 bit */
    for (x = LLONG_MIN; x < INT_MIN; x += LLSTEP)
        for (y = INT_MIN; y < 0; y += LSTEP)
            func(x, y);
}

void func2_lo_lo(void *param)
{
    PFUNC2 func;
    __int64 x, y;

    func = (PFUNC2) param;

    /* positive values below 32 bit, positive values below 32 bit */
    for (x = INT_MAX; x > 0; x -= LSTEP)
        for (y = x; y > 0; y -= LSTEP)
            func(x, y);

    /* negative values below 32 bit, negative values below 32 bit */
    for (x = INT_MIN; x < 0; x += LSTEP)
        for (y = x; y < 0; y += LSTEP)
            func(x, y);
}

void ufunc2_hi_hi(void *param)
{
    PFUNC2 func;
    unsigned __int64 x, y;

    func = (PFUNC2) param;

    /* positive values above 32 bit, positive values above 32bit */
    for (x = ULLONG_MAX; x > ULLSTEP; x -= ULLSTEP)
        for (y = x; y > ULLSTEP; y -= ULLSTEP)
            { func(x, y); func(x, y); }
}

void ufunc2_hi_lo(void *param)
{
    PFUNC2 func;
    unsigned __int64 x, y;

    func = (PFUNC2) param;

    /* positive values above 32 bit, positive values below 32 bit */
    for (x = ULLONG_MAX; x > ULLSTEP; x -= ULLSTEP)
        for (y = UINT_MAX; y > ULSTEP; y -= ULSTEP)
            { func(x, y); func(x, y); }
}

void ufunc2_lo_lo(void *param)
{
    PFUNC2 func;
    unsigned __int64 x, y;

    func = (PFUNC2) param;

    /* positive values below 32 bit, positive values below 32 bit */
    for (x = UINT_MAX; x > ULSTEP; x -= ULSTEP)
        for (y = x; y > ULSTEP; y -= ULSTEP)
            { func(x, y); func(x, y); }
}

/* helper functions for calling divrem type functions */

void func3_hi_hi(void *param)
{
    PFUNC3 func;
    __int64 x, y, r;

    func = (PFUNC3) param;

    /* positive values above 32 bit, positive values above 32bit */
    for (x = LLONG_MAX; x > INT_MAX; x -= LLSTEP)
        for (y = x; y > INT_MAX; y -= LLSTEP)
            func(x, y, &r);

    /* negative values above 32 bit, negative values above 32 bit */
    for (x = LLONG_MIN; x < INT_MIN; x += LLSTEP)
        for (y = x; y < INT_MIN; y += LLSTEP)
            func(x, y, &r);
}

void func3_hi_lo(void *param)
{
    PFUNC3 func;
    __int64 x, y, r;

    func = (PFUNC3) param;

    /* positive values above 32 bit, positive values below 32 bit */
    for (x = LLONG_MAX; x > INT_MAX; x -= LLSTEP)
        for (y = INT_MAX; y > 0; y -= LSTEP)
            func(x, y, &r);

    /* negative values above 32 bit, negative values below 32 bit */
    for (x = LLONG_MIN; x < INT_MIN; x += LLSTEP)
        for (y = INT_MIN; y < 0; y += LSTEP)
            func(x, y, &r);
}

void func3_lo_lo(void *param)
{
    PFUNC3 func;
    __int64 x, y, r;

    func = (PFUNC3) param;

    /* positive values below 32 bit, positive values below 32 bit */
    for (x = INT_MAX; x > 0; x -= LSTEP)
        for (y = x; y > 0; y -= LSTEP)
            func(x, y, &r);

    /* negative values below 32 bit, negative values below 32 bit */
    for (x = INT_MIN; x < 0; x += LSTEP)
        for (y = x; y < 0; y += LSTEP)
            func(x, y, &r);
}

void ufunc3_hi_hi(void *param)
{
    PFUNC3 func;
    unsigned __int64 x, y, r;

    func = (PFUNC3) param;

    /* positive values above 32 bit, positive values above 32bit */
    for (x = ULLONG_MAX; x > ULLSTEP; x -= ULLSTEP)
        for (y = x; y > ULLSTEP; y -= ULLSTEP)
            { func(x, y, &r); func(x, y, &r); }
}

void ufunc3_hi_lo(void *param)
{
    PFUNC3 func;
    unsigned __int64 x, y, r;

    func = (PFUNC3) param;

    /* positive values above 32 bit, positive values below 32 bit */
    for (x = ULLONG_MAX; x > ULLSTEP; x -= ULLSTEP)
        for (y = UINT_MAX; y > ULSTEP; y -= ULSTEP)
            { func(x, y, &r); func(x, y, &r); }
}

void ufunc3_lo_lo(void *param)
{
    PFUNC3 func;
    unsigned __int64 x, y, r;

    func = (PFUNC3) param;

    /* positive values below 32 bit, positive values below 32 bit */
    for (x = UINT_MAX; x > ULSTEP; x -= ULSTEP)
        for (y = x; y > ULSTEP; y -= ULSTEP)
            { func(x, y, &r); func(x, y, &r); }
}

/* time func, by taking minimum time over a number of calls */
__int64 time_func(PTIMEFUNC func, void *param)
{
    LARGE_INTEGER start, end;
    __int64 minimum, overhead, result;
    int i;

    minimum = LLONG_MAX;

    /* increase our priority to avoid (some) interruptions */
    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);

    /* time overhead */
    for (i = 0; i < 1024; ++i)
    {
        QueryPerformanceCounter(&start);
        /* blank */
        QueryPerformanceCounter(&end);
        result = end.QuadPart - start.QuadPart;
        if (result < minimum) minimum = result;
    }

    overhead = minimum;
    minimum = LLONG_MAX;

    /* actual timing */
    for (i = 0; i < 1024; ++i)
    {
        QueryPerformanceCounter(&start);
        func(param);
        QueryPerformanceCounter(&end);
        result = end.QuadPart - start.QuadPart;
        if (result < minimum) minimum = result;
    }

    /* restore normal priority */
    SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);

    return minimum - overhead;
}

void do_timing_line(const char *name, PTIMEFUNC timefunc, void *func1, void *func2)
{
    __int64 t1, t2;

    t1 = time_func(timefunc, func1);
    t2 = time_func(timefunc, func2);

    printf("%-12s  %8lld  %8lld  %+8.1f%%\n", name, t1, t2, 100.0 - ((double ) t1*100)/(double) t2);
}

/* disable warnings about parameter mismatches, we will be calling the compare
   functions on both signed and unsigned versions */
#ifdef _MSC_VER
# pragma warning(disable:4028)
#endif

int main(int argc, char *argv[])
{
    fix_affinity();

    printf("--- Comparing return values ---\n\n");
    printf("signed div\t%s\n", func2_compare(msalldiv, nwalldiv) ? "ERROR" : "OK");
    printf("signed divrem\t%s\n", func3_compare(msalldvrm, nwalldvrm) ? "ERROR" : "OK");
    printf("signed mul\t%s\n", func2_compare(msallmul, nwallmul) ? "ERROR" : "OK");
    printf("signed rem\t%s\n", func2_compare(msallrem, nwallrem) ? "ERROR" : "OK");
    printf("signed shl\t%s\n", func1_compare(msallshl, nwallshl) ? "ERROR" : "OK");
    printf("signed shr\t%s\n", func1_compare(msallshr, nwallshr) ? "ERROR" : "OK");
    printf("unsigned div\t%s\n", func2_compare(msaulldiv, nwaulldiv) ? "ERROR" : "OK");
    printf("unsigned divrem\t%s\n", func3_compare(msaulldvrm, nwaulldvrm) ? "ERROR" : "OK");
    printf("unsigned rem\t%s\n", func2_compare(msaullrem, nwaullrem) ? "ERROR" : "OK");
    printf("unsigned shr\t%s\n", func1_compare(msaullshr, nwaullshr) ? "ERROR" : "OK");

    printf("\n--- Timing ---\n\n");

    printf("Function          WCRT        VC       Diff\n");
    printf("-------------------------------------------\n");
    do_timing_line("HH _alldiv", func2_hi_hi, nwalldiv, msalldiv);
    do_timing_line("HL _alldiv", func2_hi_lo, nwalldiv, msalldiv);
    do_timing_line("LL _alldiv", func2_lo_lo, nwalldiv, msalldiv);
    printf("\n");
    do_timing_line("HH _alldvrm", func3_hi_hi, nwalldvrm, msalldvrm);
    do_timing_line("HL _alldvrm", func3_hi_lo, nwalldvrm, msalldvrm);
    do_timing_line("LL _alldvrm", func3_lo_lo, nwalldvrm, msalldvrm);
    printf("\n");
    do_timing_line("HH _allmul", func2_hi_hi, nwallmul, msallmul);
    do_timing_line("HL _allmul", func2_hi_lo, nwallmul, msallmul);
    do_timing_line("LL _allmul", func2_lo_lo, nwallmul, msallmul);
    printf("\n");
    do_timing_line("HH _allrem", func2_hi_hi, nwallrem, msallrem);
    do_timing_line("HL _allrem", func2_hi_lo, nwallrem, msallrem);
    do_timing_line("LL _allrem", func2_lo_lo, nwallrem, msallrem);
    printf("\n");
    do_timing_line("<32 _allshl", func1_32, nwallshl, msallshl);
    do_timing_line("<64 _allshl", func1_64, nwallshl, msallshl);
    do_timing_line("<96 _allshl", func1_96, nwallshl, msallshl);
    printf("\n");
    do_timing_line("<32 _allshr", func1_32, nwallshr, msallshr);
    do_timing_line("<64 _allshr", func1_64, nwallshr, msallshr);
    do_timing_line("<96 _allshr", func1_96, nwallshr, msallshr);
    printf("\n");
    do_timing_line("HH _aulldiv", ufunc2_hi_hi, nwaulldiv, msaulldiv);
    do_timing_line("HL _aulldiv", ufunc2_hi_lo, nwaulldiv, msaulldiv);
    do_timing_line("LL _aulldiv", ufunc2_lo_lo, nwaulldiv, msaulldiv);
    printf("\n");
    do_timing_line("HH _aulldvrm", ufunc3_hi_hi, nwaulldvrm, msaulldvrm);
    do_timing_line("HL _aulldvrm", ufunc3_hi_lo, nwaulldvrm, msaulldvrm);
    do_timing_line("LL _aulldvrm", ufunc3_lo_lo, nwaulldvrm, msaulldvrm);
    printf("\n");
    do_timing_line("HH _aullrem", ufunc2_hi_hi, nwaullrem, msaullrem);
    do_timing_line("HL _aullrem", ufunc2_hi_lo, nwaullrem, msaullrem);
    do_timing_line("LL _aullrem", ufunc2_lo_lo, nwaullrem, msaullrem);
    printf("\n");
    do_timing_line("<32 _aullshr", func1_32, nwaullshr, msaullshr);
    do_timing_line("<64 _aullshr", func1_64, nwaullshr, msaullshr);
    do_timing_line("<96 _aullshr", func1_96, nwaullshr, msaullshr);
    printf("\n");

    return 1;
}
