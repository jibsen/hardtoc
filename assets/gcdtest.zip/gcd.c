
#include "gcd.h"

/* extended GCD algorithm with 32-bit integers
 * returns the GCD of x and y, setting a and b so gcd = a*x + b*y
 * taken from http://en.wikipedia.org/wiki/Extended_Euclidean_algorithm
 */
int gcdext32(int *a, int *b, int x, int y)
{
    int u, v, lastu, lastv;

    u = 0;
    v = 1;
    lastu = 1;
    lastv = 0;

    while (y != 0)
    {
        int t, quotient;

        quotient = x / y;

        t = y;
        y = x % y;
        x = t;

        t = u;
        u = lastu - quotient*u;
        lastu = t;

        t = v;
        v = lastv - quotient*v;
        lastv = t;
    }

    *a = lastu;
    *b = lastv;

    return x;
}

/* extended GCD algorithm with 64-bit integers */
long long gcdext64(long long *a, long long *b, long long x, long long y)
{
    long long u, v, lastu, lastv;

    u = 0;
    v = 1;
    lastu = 1;
    lastv = 0;

    while (y != 0)
    {
        long long t, quotient;

        quotient = x / y;

        t = y;
        y = x % y;
        x = t;

        t = u;
        u = lastu - quotient*u;
        lastu = t;

        t = v;
        v = lastv - quotient*v;
        lastv = t;
    }

    *a = lastu;
    *b = lastv;

    return x;
}
