/* Simple test program to time 32- and 64-bit GCD function.
 *
 * Make sure you disable any whole program optimization/link time code
 * generation.
 */

#define WIN32_LEAN_AND_MEAN

#include <windows.h>

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>

#include "gcd.h"

/* call 32-bit GCD for a range of values */
void gcdtest32()
{
    int x, y, a, b;

    for (x = INT_MAX; x > 0; x /= 2)
        for (y = INT_MAX - 1; y > 0; y /= 2)
            gcdext32(&a, &b, x, y);
}

/* call 64-bit GCD for a range of values */
void gcdtest64()
{
    int x, y;
    long long a, b;

    for (x = INT_MAX; x > 0; x /= 2)
        for (y = INT_MAX - 1; y > 0; y /= 2)
            gcdext64(&a, &b, x, y);
}

/* time func, by taking minimum time over a number of calls */
long long time_func(void (*func)())
{
    LARGE_INTEGER start, end;
    long long minimum, overhead, result;
    int i;

    minimum = LLONG_MAX;

    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);

    /* time overhead */
    for (i = 0; i < 1024; ++i)
    {
        QueryPerformanceCounter(&start);
        /* blank */
        QueryPerformanceCounter(&end);
        result = end.QuadPart - start.QuadPart;
        if (result < minimum) minimum = result;
    }

    overhead = minimum;
    minimum = LLONG_MAX;

    /* actual timing */
    for (i = 0; i < 1024; ++i)
    {
        QueryPerformanceCounter(&start);
        func();
        QueryPerformanceCounter(&end);
        result = end.QuadPart - start.QuadPart;
        if (result < minimum) minimum = result;
    }

    SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);

    return minimum - overhead;
}

int main()
{
    printf("32-bit GCD: %lld\n", time_func(gcdtest32));
    printf("64-bit GCD: %lld\n", time_func(gcdtest64));

    return 1;
}
