
#ifndef GCD_H_INCLUDED
#define GCD_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

int gcdext32(int *a, int *b, int x, int y);

long long gcdext64(long long *a, long long *b, long long x, long long y);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* GCD_H_INCLUDED */
